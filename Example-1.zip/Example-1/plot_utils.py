import numpy as np
from matplotlib import pyplot as plt
from matplotlib.ticker import FuncFormatter, LogLocator, LogFormatterMathtext
from matplotlib.patches import Patch

    
    TT, XX = np.meshgrid(t_pred, x_pred)

        for model_name in predictions:
        fig = plt.figure(figsize=(10, 8))
        ax = fig.add_subplot(111, projection='3d')
        colors = plt.cm.tab10(np.linspace(0, 1, len(alpha_values)))
        num_alphas = len(alpha_values)
        for i, alpha in enumerate(alpha_values):
            surface = predictions[model_name][alpha].reshape(x_pred_N, t_pred_N)
            ax.plot_surface(TT, XX, surface, color=colors[i], alpha=0.6)
        ax.set_title(f'{model_name} Predicted 3D Solutions (all α)', pad=20)
        ax.set_xlabel('t', labelpad=15)
        ax.set_ylabel('x', labelpad=15)
        ax.set_zlabel('u', labelpad=15)
        handles = [Patch(color=colors[i], label=f'α = {alpha_values[i]}') for i in range(num_alphas)]
        fig.legend(handles, [f'α = {alpha}' for alpha in alpha_values], loc='upper center',
                   ncol=int(np.ceil(num_alphas / 3)), bbox_to_anchor=(0.5, 1.05))
        plt.tight_layout(rect=[0, 0, 1, 0.9])
        plt.savefig(f'Results/Figures/{model_name}_3D_solutions_overlay.pdf', bbox_inches='tight')
        plt.show()

        
        n_alphas = len(alpha_values)
        colors = plt.cm.viridis(np.linspace(0, 1, n_alphas))
        for idx, alpha in enumerate(alpha_values):
            surface = predictions[model_name][alpha].reshape(x_pred_N, t_pred_N)
            fig = plt.figure(figsize=(10, 8))
            ax = fig.add_subplot(111, projection='3d')
            ax.plot_surface(TT, XX, surface, color=colors[idx], edgecolor='none', alpha=0.95)
            ax.set_title(f'{model_name} — 3D Solution (α = {alpha})', pad=18)
            ax.set_xlabel('t', labelpad=14)
            ax.set_ylabel('x', labelpad=14)
            ax.set_zlabel('u', labelpad=14)
            plt.tight_layout()
            out_name = f"Results/Figures/{model_name}_3D_alpha_{str(alpha).replace('.', '_')}.pdf"
            plt.savefig(out_name, bbox_inches='tight')
            plt.show()
            plt.close(fig)

        alpha_list = alpha_values
    t_target = 0.5
    t_index = np.argmin(np.abs(t_pred.flatten() - t_target))
    n_alphas = len(alpha_list)
    rows = int(np.ceil(np.sqrt(n_alphas)))
    cols = int(np.ceil(n_alphas / rows))
    fig, axs = plt.subplots(rows, cols, figsize=(cols * 5, rows * 5))
    axs = np.array(axs).flatten()
    for idx, alpha in enumerate(alpha_list):
        for model_name in ["Net", "ChebyKAN", "KAN"]:
            pred = predictions[model_name][alpha].reshape(x_pred_N, t_pred_N)
            axs[idx].plot(x_pred.flatten(), pred[:, t_index], label=model_name)
        axs[idx].set_title(f'α = {alpha}')
        axs[idx].set_xlabel('x', labelpad=10)
        axs[idx].set_ylabel('u', labelpad=10)
        axs[idx].grid(True, linestyle='--', alpha=0.6)
    for ax in axs[n_alphas:]:
        fig.delaxes(ax)
    handles, labels = axs[0].get_legend_handles_labels()
    fig.legend(handles, labels, loc='upper center', ncol=3)
    plt.suptitle(f'Predicted Solution at t = {t_target}', fontsize=20)
    plt.tight_layout(rect=[0, 0.03, 1, 0.95])
    plt.savefig(f'Results/Figures/2D_Subplot_Comparison_t_{t_target}.pdf', bbox_inches='tight')
    plt.show()

    t_target = 0.7
    t_index = np.argmin(np.abs(t_pred.flatten() - t_target))
    n_alphas = len(alpha_list)
    rows = int(np.ceil(np.sqrt(n_alphas)))
    cols = int(np.ceil(n_alphas / rows))
    fig, axs = plt.subplots(rows, cols, figsize=(cols * 5, rows * 5))
    axs = np.array(axs).flatten()
    for idx, alpha in enumerate(alpha_list):
        for model_name in ["Net", "ChebyKAN", "KAN"]:
            pred = predictions[model_name][alpha].reshape(x_pred_N, t_pred_N)
            axs[idx].plot(x_pred.flatten(), pred[:, t_index], label=model_name)
        axs[idx].set_title(f'α = {alpha}')
        axs[idx].set_xlabel('x', labelpad=10)
        axs[idx].set_ylabel('u', labelpad=10)
        axs[idx].grid(True, linestyle='--', alpha=0.6)
    for ax in axs[n_alphas:]:
        fig.delaxes(ax)
    handles, labels = axs[0].get_legend_handles_labels()
    fig.legend(handles, labels, loc='upper center', ncol=3)
    plt.suptitle(f'Predicted Solution at t = {t_target}', fontsize=20)
    plt.tight_layout(rect=[0, 0.03, 1, 0.95])
    plt.savefig(f'Results/Figures/2D_Subplot_Comparison_t_{t_target}.pdf', bbox_inches='tight')
    plt.show()

    t_target = 0.5
    t_index = np.argmin(np.abs(t_pred.flatten() - t_target))
    for model_name in ["Net", "ChebyKAN", "KAN"]:
        plt.figure(figsize=(10, 6))
        for alpha in alpha_values:
            pred = predictions[model_name][alpha].reshape(x_pred_N, t_pred_N)
            plt.plot(x_pred.flatten(), pred[:, t_index], label=f'α = {alpha}')
        plt.title(f'{model_name} Predicted Solution at t = {t_target}', pad=15)
        plt.xlabel('x', labelpad=10)
        plt.ylabel('u', labelpad=10)
        plt.legend()
        plt.grid(True, linestyle='--', alpha=0.6)
        plt.tight_layout()
        plt.savefig(f'Results/Figures/{model_name}_2D_Solution_t_{t_target}.pdf', bbox_inches='tight')
        plt.show()

    t_target = 0.7
    t_index = np.argmin(np.abs(t_pred.flatten() - t_target))
    for model_name in ["Net", "ChebyKAN", "KAN"]:
        plt.figure(figsize=(10, 6))
        for alpha in alpha_values:
            pred = predictions[model_name][alpha].reshape(x_pred_N, t_pred_N)
            plt.plot(x_pred.flatten(), pred[:, t_index], label=f'α = {alpha}')
        plt.title(f'{model_name} Predicted Solution at t = {t_target}', pad=15)
        plt.xlabel('x', labelpad=10)
        plt.ylabel('u', labelpad=10)
        plt.legend()
        plt.grid(True, linestyle='--', alpha=0.6)
        plt.tight_layout()
        plt.savefig(f'Results/Figures/{model_name}_2D_Solution_t_{t_target}.pdf', bbox_inches='tight')
        plt.show()

   
    for model_name in ["Net", "ChebyKAN", "KAN"]:
        plt.figure(figsize=(10, 6))
        # Collect all loss values for scaling
        all_losses = [val for alpha in alpha_values for val in loss_histories[model_name][alpha]]
        if len(all_losses) == 0:
            plt.close()
            continue
        e = int(np.floor(np.log10(max(all_losses) + 1e-300)))
        scale = 10.0 ** e

        for alpha in alpha_values:
            hist = np.array(loss_histories[model_name][alpha]) / scale
            if hist.size == 0:
                continue
            plt.plot(hist, label=fr'$\alpha={alpha}$', linewidth=2.0)

        plt.xlabel('Iteration', labelpad=10)
        plt.ylabel('Loss', labelpad=10)
        plt.title(f'{model_name} Training Loss (Log Scale) for all $\\alpha$', pad=15)

        ax = plt.gca()
        ax.set_yscale('log')
        ax.yaxis.set_major_locator(LogLocator(base=10))
        ax.yaxis.set_major_formatter(LogFormatterMathtext())
        ax.yaxis.set_minor_locator(LogLocator(base=10, subs=np.arange(2, 10) * 0.1))

        # Add ×10^n in upper-left corner
        ax.text(0.0, 1.02, rf'×10$^{{{e}}}$', transform=ax.transAxes,
                ha='left', va='bottom', fontsize=16)

        plt.grid(True, which='both', linestyle='--', alpha=0.6)
        plt.legend(title='Alphas', ncol=2, frameon=False)
        plt.tight_layout()
        plt.savefig(f'Results/Figures/{model_name}_loss_all_alphas_log.pdf', bbox_inches='tight')
        plt.show()
