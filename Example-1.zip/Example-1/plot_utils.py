import numpy as np
from matplotlib import pyplot as plt
from matplotlib.ticker import FuncFormatter, LogLocator, LogFormatterMathtext
from matplotlib.patches import Patch

def plot_surface_single(TT, XX, ZZ, title, fname, cmap='viridis'):
    fig = plt.figure(figsize=(10, 8))
    ax = fig.add_subplot(111, projection='3d')
    surf = ax.plot_surface(TT, XX, ZZ, cmap=cmap, edgecolor='none', alpha=1.0)
    from matplotlib.ticker import ScalarFormatter
    ax.zaxis.set_major_formatter(ScalarFormatter(useMathText=True))
    ax.ticklabel_format(axis='z', style='sci', scilimits=(-1, 1))
    ax.set_title(title, pad=20)
    ax.set_xlabel('t', labelpad=15)
    ax.set_ylabel('x', labelpad=15)
    ax.set_zlabel('u' if 'Error' not in title else 'Error', labelpad=20)
    plt.tight_layout()
    plt.savefig(fname, bbox_inches='tight')
    plt.show()
    plt.close(fig)

def plot_error_heatmap(error_data, t_pred, x_pred, title, fname, cmap='plasma'):
    plt.figure(figsize=(8, 6))
    im = plt.imshow(error_data.T, origin='lower',
                    extent=[t_pred.min(), t_pred.max(), x_pred.min(), x_pred.max()],
                    aspect='auto', cmap=cmap)
    plt.colorbar(im, label='Absolute Error')
    plt.xlabel('t', labelpad=10)
    plt.ylabel('x', labelpad=10)
    plt.title(title, pad=15)
    plt.tight_layout()
    plt.savefig(fname, bbox_inches='tight')
    plt.show()
    plt.close()