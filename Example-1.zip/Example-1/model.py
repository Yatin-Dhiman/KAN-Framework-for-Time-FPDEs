import os
import time
import math
import numpy as np
import torch
from torch.autograd import Variable

from .caputo_L1 import caputo_L1

class Model:
    def __init__(self, order, net, x0, u0, t, lb, ub, x_test, x_test_exact, exact_u, exact_u0, alpha):
        self.order = order
        self.net = net
        self.x0 = x0
        self.u0 = u0
        self.x_N = len(x0)
        self.t = t
        self.t_N = len(t)
        self.dt = (ub[0] - lb[0]) / (self.t_N - 1)
        self.lb = lb
        self.ub = ub
        self.x_test = x_test
        self.x_test_exact = x_test_exact
        self.exact_u = exact_u
        self.exact_u0 = exact_u0
        self.x_b_loss_collect = []
        self.x_f_loss_collect = []
        self.loss_history = []
        self.alpha = alpha
        self.init_data()

    def init_data(self):
        temp_t = torch.full_like(torch.zeros(self.x_N, 1, dtype=torch.get_default_dtype()), self.t[0])
        self.x_f = torch.cat((temp_t, self.x0), dim=1)
        for i in range(self.t_N - 1):
            temp_t = torch.full_like(torch.zeros(self.x_N, 1, dtype=torch.get_default_dtype()), self.t[i + 1])
            x_f_temp = torch.cat((temp_t, self.x0), dim=1)
            self.x_f = torch.cat((self.x_f, x_f_temp), dim=0)
        temp_t = torch.from_numpy(self.t[:, None]).to(dtype=torch.get_default_dtype())
        temp_lb = torch.full_like(torch.zeros(self.t_N, 1, dtype=torch.get_default_dtype()), self.lb[1])
        temp_ub = torch.full_like(torch.zeros(self.t_N, 1, dtype=torch.get_default_dtype()), self.ub[1])
        self.x_b1 = torch.cat((temp_t, temp_lb), dim=1)
        self.x_b2 = torch.cat((temp_t, temp_ub), dim=1)
        self.x_b1_u = self.exact_u(self.x_b1)
        self.x_b2_u = self.exact_u(self.x_b2)
        self.lb = torch.from_numpy(self.lb).to(dtype=torch.get_default_dtype())
        self.ub = torch.from_numpy(self.ub).to(dtype=torch.get_default_dtype())

    def train_U(self, x):
        H = 2.0 * (x - self.lb) / (self.ub - self.lb) - 1.0
        return self.net(H) * x[:, [0]] + torch.exp(x[:, [1]])

    def predict_U(self, x):
        return self.train_U(x)

    def hat_ut_and_Lu(self):
        x = Variable(self.x_f, requires_grad=True)
        u = self.train_U(x)
        # first derivatives
        d = torch.autograd.grad(u, x, grad_outputs=torch.ones_like(u), create_graph=True)
        u_t = d[0][:, [0]]
        u_x = d[0][:, [1]]
        # second derivatives
        dd = torch.autograd.grad(u_x, x, grad_outputs=torch.ones_like(u_x), create_graph=True)
        u_xx = dd[0][:, [1]]
        # third derivative (kept for compatibility)
        ddd = torch.autograd.grad(u_xx, x, grad_outputs=torch.ones_like(u_xx), create_graph=True)
        u_xxx = ddd[0][:, [1]]
        # second time derivative (not used for Caputo-L1, but computed)
        u_tt = torch.autograd.grad(u_t, x, grad_outputs=torch.ones_like(u_t), create_graph=True)[0][:, [0]]

        # reshape to [t_N, x_N]
        u = u.reshape(self.t_N, self.x_N)
        u_t = u_t.reshape(self.t_N, self.x_N)
        u_tt = u_tt.reshape(self.t_N, self.x_N)
        u_x = d[0][:, [1]].reshape(self.t_N, self.x_N)
        u_xx = dd[0][:, [1]].reshape(self.t_N, self.x_N)

        # Forcing term f(t,x; alpha)
        func = ((6 * (x[:, [0]]) ** (3 - self.alpha)) / math.gamma(4 - self.alpha) + (x[:, [0]]) ** 3) * torch.cos(x[:, [1]]) - torch.exp(x[:, [1]])
        Lu = u_xx + func.reshape(self.t_N, self.x_N)
        Lu = Lu.reshape(self.t_N, self.x_N)
        return u, u_t, Lu, u_tt

    def PDE_loss(self):
        # Compute u and Lu on grid
        u, u_t, Lu, u_tt = self.hat_ut_and_Lu()
        # Use Caputo L1 for fractional time derivative
        t_tensor = torch.tensor(self.t, dtype=u.dtype, device=u.device)
        D_alpha = caputo_L1(u, t_tensor, self.alpha)
        loss = torch.mean((D_alpha[1:] - Lu[1:]) ** 2)
        return loss

    def calculate_loss(self):
        loss_b1 = torch.mean((self.train_U(self.x_b1) - self.x_b1_u) ** 2)
        loss_b2 = torch.mean((self.train_U(self.x_b2) - self.x_b2_u) ** 2)
        loss_b = loss_b1 + loss_b2
        self.x_b_loss_collect.append([self.net.iter, loss_b.item()])
        loss_f = self.PDE_loss()
        self.x_f_loss_collect.append([self.net.iter, loss_f.item()])
        return loss_b, loss_f

    def LBGFS_loss(self):
        # kept for API compatibility but not used in Adam training
        self.optimizer_LBGFS.zero_grad()
        loss_b, loss_f = self.calculate_loss()
        loss = loss_b + loss_f
        loss.backward()
        if hasattr(self.net, "iter"):
            self.net.iter += 1
        else:
            self.net.iter = 1
        self.loss_history.append(loss.item())
        print("Iter:", self.net.iter, "Loss:", loss.item())
        return loss

    def train(self, epochs=5000, lr=0.001, print_every=100):
        # Use Adam optimizer with lr=0.001 as requested
        optimizer = torch.optim.Adam(self.net.parameters(), lr=lr)
        for ep in range(epochs):
            optimizer.zero_grad()
            loss_b, loss_f = self.calculate_loss()
            loss = loss_b + loss_f
            loss.backward()
            optimizer.step()

            if not hasattr(self.net, "iter"):
                self.net.iter = 0
            self.net.iter += 1
            self.loss_history.append(loss.item())

            if (ep + 1) % print_every == 0 or ep == 0:
                print(f"Epoch {ep+1}/{epochs}  Loss = {loss.item():.6e}  (loss_b={loss_b.item():.3e}, loss_f={loss_f.item():.3e})")

        # After training compute test error and timing
        pred = self.predict_U(self.x_test).cpu().detach().numpy()
        exact = self.x_test_exact.cpu().detach().numpy()
        error = np.linalg.norm(pred - exact, 2) / (np.linalg.norm(exact, 2) + 1e-16)
        print("Final Test L2 relative error:", error)
        return error, None, float(self.loss_history[-1]) if len(self.loss_history) else float('nan')