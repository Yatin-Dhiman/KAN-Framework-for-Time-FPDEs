import os
import numpy as np
import torch
from .utils import set_seed, compute_metrics_flat
from .networks import ChebyKAN, KAN, Net
from .model import Model
from .plot_utils import plot_surface_single, plot_error_heatmap

def show_comparison():
    lb = np.array([0.0, 0.0])
    ub = np.array([1.0, 1.0])
    t_N = 51
    x_N = 110
    alpha = 1
    train_t = np.linspace(lb[0], ub[0], t_N)
    x0 = np.linspace(lb[1], ub[1], x_N)[:, None]
    x0 = torch.from_numpy(x0).float()
    exact_u = lambda x: (x[:, [0]]**3) * torch.cos(x[:, [1]]) + torch.exp(x[:, [1]])
    exact_u0 = lambda x: exact_u(torch.cat((torch.zeros_like(x), x), dim=1))
    u0 = exact_u0(x0)

    t_pred_N = 100
    x_pred_N = 100
    t_pred = np.linspace(lb[0], ub[0], t_pred_N)[:, None]
    x_pred = np.linspace(lb[1], ub[1], x_pred_N)[:, None]
    t_star, x_star = np.meshgrid(t_pred, x_pred)
    tx = np.hstack((t_star.flatten()[:, None], x_star.flatten()[:, None]))
    x_test = torch.from_numpy(tx)
    x_test_exact = exact_u(x_test)

    set_seed(1234)
    layers = [2, 20, 20, 20, 1]

    net_cheby = ChebyKAN(layers, degree=8)
    net_kan = KAN(layers, grid_size=5, spline_order=3, scale_noise=0.1,
                  scale_base=1.0, scale_spline=1.0, base_activation=torch.nn.SiLU,
                  grid_eps=0.02, grid_range=[-1, 1])
    net_fc = Net(layers)

    model_cheby = Model(order=0, net=net_cheby, x0=x0, u0=u0, t=train_t,
                        lb=lb, ub=ub, x_test=x_test, x_test_exact=x_test_exact,
                        exact_u=exact_u, exact_u0=exact_u0, alpha=alpha)
    model_kan = Model(order=0, net=net_kan, x0=x0, u0=u0, t=train_t,
                      lb=lb, ub=ub, x_test=x_test, x_test_exact=x_test_exact,
                      exact_u=exact_u, exact_u0=exact_u0, alpha=alpha)
    model_fc = Model(order=0, net=net_fc, x0=x0, u0=u0, t=train_t,
                     lb=lb, ub=ub, x_test=x_test, x_test_exact=x_test_exact,
                     exact_u=exact_u, exact_u0=exact_u0, alpha=alpha)

    print("Training ChebyKAN model...")
    error_cheby, elapsed_cheby, final_loss_cheby = model_cheby.train(epochs=300)

    print("Training KAN model...")
    error_kan, elapsed_kan, final_loss_kan = model_kan.train(epochs=300)

    print("Training Net (Fully Connected) model...")
    error_fc, elapsed_fc, final_loss_fc = model_fc.train(epochs=300)

    print("Done show_comparison")

def show_combined():
    lb = np.array([0.0, 0.0])
    ub = np.array([1.0, 1.0])
    t_N = 51
    x_N = 110
    train_t = np.linspace(lb[0], ub[0], t_N)
    x0 = np.linspace(lb[1], ub[1], x_N)[:, None]
    x0 = torch.from_numpy(x0).float()
    exact_u = lambda x: (x[:, [0]]**3) * torch.cos(x[:, [1]]) + torch.exp(x[:, [1]])
    exact_u0 = lambda x: exact_u(torch.cat((torch.zeros_like(x), x), dim=1))
    u0 = exact_u0(x0)

    layers = [2, 20, 20, 20, 1]
    t_pred_N = 100
    x_pred_N = 100
    t_pred = np.linspace(lb[0], ub[0], t_pred_N)[:, None]
    x_pred = np.linspace(lb[1], ub[1], x_pred_N)[:, None]
    TT, XX = np.meshgrid(t_pred, x_pred)
    tx = np.hstack((TT.flatten()[:, None], XX.flatten()[:, None]))
    x_test = torch.from_numpy(tx).to(dtype=torch.get_default_dtype())
    x_test_exact = exact_u(x_test)

    set_seed(1234)
    alpha_values = [0.1, 0.3, 0.5, 0.7, 0.9]
    predictions = {"Net": {}, "ChebyKAN": {}, "KAN": {}}

    for alpha in alpha_values:
        print(f"Training for alpha = {alpha}")
        net_fc = Net(layers)
        model_fc = Model(order=0, net=net_fc, x0=x0, u0=u0, t=train_t,
                         lb=lb, ub=ub, x_test=x_test, x_test_exact=x_test_exact,
                         exact_u=exact_u, exact_u0=exact_u0, alpha=alpha)
        err_fc, elapsed_fc, final_loss_fc = model_fc.train(epochs=3)
        predictions["Net"][alpha] = model_fc.predict_U(model_fc.x_test).cpu().detach().numpy()

        net_cheby = ChebyKAN(layers, degree=4)
        model_cheby = Model(order=0, net=net_cheby, x0=x0, u0=u0, t=train_t,
                            lb=lb, ub=ub, x_test=x_test, x_test_exact=x_test_exact,
                            exact_u=exact_u, exact_u0=exact_u0, alpha=alpha)
        err_c, elapsed_c, final_loss_c = model_cheby.train(epochs=3)
        predictions["ChebyKAN"][alpha] = model_cheby.predict_U(model_cheby.x_test).cpu().detach().numpy()

        net_kan = KAN(layers, grid_size=5, spline_order=3, scale_noise=0.1, scale_base=1.0,
                      scale_spline=1.0, base_activation=torch.nn.SiLU, grid_eps=0.02, grid_range=[-1, 1])
        model_kan = Model(order=0, net=net_kan, x0=x0, u0=u0, t=train_t,
                          lb=lb, ub=ub, x_test=x_test, x_test_exact=x_test_exact,
                          exact_u=exact_u, exact_u0=exact_u0, alpha=alpha)
        err_k, elapsed_k, final_loss_k = model_kan.train(epochs=3)
        predictions["KAN"][alpha] = model_kan.predict_U(model_kan.x_test).cpu().detach().numpy()

    print("Completed show_combined")

if __name__ == '__main__':
    import sys
    if len(sys.argv) > 1 and sys.argv[1] == 'show_combined':
        show_combined()
    else:
        show_comparison()
