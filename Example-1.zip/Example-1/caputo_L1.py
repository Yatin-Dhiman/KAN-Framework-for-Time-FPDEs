import torch
import math

def caputo_L1(u: torch.Tensor, t: torch.Tensor, alpha: float):
    # Compute the Caputo L1 fractional derivative D_t^alpha u using uniform timestep assumption.
    # u: tensor of shape (t_N, x_N)
    # t: 1D tensor of time points (t_N)
    # alpha: fractional order (0 < alpha < 1)
    # returns: tensor of shape (t_N, x_N) (first row zeros)
    assert u.dim() == 2, "u must be (t_N, x_N)"
    t = t.double()
    dt = float(t[1] - t[0])
    t_N, x_N = u.shape
    frac = torch.zeros_like(u, dtype=u.dtype, device=u.device)

    coef = 1.0 / (math.gamma(2.0 - alpha) * (dt ** alpha))

    for n in range(1, t_N):
        ks = torch.arange(0, n, device=u.device)
        # compute weights w_{n,k} using Python math then move to torch (small n so ok)
        w = torch.tensor([ ( (n - int(k))**(1.0 - alpha) - (n - int(k) - 1)**(1.0 - alpha) ) for k in ks ], dtype=u.dtype, device=u.device)
        diffs = u[1:n+1, :] - u[0:n, :]
        s = torch.matmul(w.unsqueeze(0).to(u.dtype), diffs)[0]
        frac[n, :] = coef * s
    return frac