import torch
import math

def caputo_L1(u: torch.Tensor, t: torch.Tensor, alpha: float):

    assert u.dim() == 2, 
    t = t.double()
    dt = float(t[1] - t[0])
    t_N, x_N = u.shape

    u_d = u.double()
    frac = torch.zeros_like(u_d, dtype=torch.double, device=u.device)

    
    m = torch.arange(0, t_N, device=u.device, dtype=torch.double)
    zeta = ( (m + 1.0) ** (1.0 - alpha) ) - ( m ** (1.0 - alpha) )  
    coef = (dt ** (-alpha)) / math.gamma(2.0 - alpha)

    
    for n in range(1, t_N):
        # term with f(t_n)
        term_n = zeta[0] * u_d[n]  

        
        if n > 1:
            ks = torch.arange(1, n, device=u.device)              
            idx1 = n - ks - 1   
            idx2 = n - ks       
            w = zeta[idx1] - zeta[idx2] 
            
            sum_term = (w.unsqueeze(1) * u_d[ks]).sum(dim=0)      
        else:
            sum_term = torch.zeros(x_N, dtype=torch.double, device=u.device)

        term0 = zeta[n - 1] * u_d[0]

        frac[n, :] = coef * (term_n - sum_term - term0)

    return frac.to(u.dtype)
