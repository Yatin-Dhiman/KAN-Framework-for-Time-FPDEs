import math
import numpy as np
import torch

def set_seed(seed):
    torch.set_default_dtype(torch.double)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    np.random.seed(seed)

def compute_metrics_flat(pred: np.ndarray, exact: np.ndarray):
    pred = np.asarray(pred).ravel()
    exact = np.asarray(exact).ravel()
    diff = pred - exact
    mse = float(np.mean(diff ** 2))
    l2_rel = float(np.linalg.norm(diff, 2) / (np.linalg.norm(exact, 2) + 1e-16))
    linf_abs = float(np.max(np.abs(diff)))
    linf_rel = float(linf_abs / (np.max(np.abs(exact)) + 1e-16))
    return {"MSE": mse, "L2_rel": l2_rel, "Linf_abs": linf_abs, "Linf_rel": linf_rel}